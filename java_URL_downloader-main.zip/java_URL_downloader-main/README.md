# java_URL_downloader
A java based code that can download file from url link
In the main.java we can provide our pc location for the donloaded file eg String saveDir = "C:\\Users\\91989\\Desktop";
In the main.java also add the url link eg  String fileURL = "https://ncert.nic.in/textbook/pdf/cesa1dd.zip";
